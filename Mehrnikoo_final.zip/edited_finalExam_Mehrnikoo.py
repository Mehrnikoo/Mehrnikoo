class Node:
    def __init__(self, number, workEX):
        self.number = number
        self.workEX = workEX
        self.next = None
        self.prev = None


class LinkedList:

    def __init__(self):
        self.head = None

    def add_worker(self, number, workEX):
        new_worker = Node(number, workEX)
        if not self.head:
            self.head = new_worker
        else:
            current_worker = self.head
            while current_worker.next:
                current_worker = current_worker.next
            current_worker.next = new_worker
            new_worker.prev = current_worker

    def merge_and_group(self):
        merged_pairs = []
        current_worker = self.head
        while current_worker and current_worker.next:
            merged_pairs.append(
                [current_worker.number, current_worker.workEX, current_worker.next.number, current_worker.next.workEX])
            current_worker = current_worker.next.next
        return merged_pairs

    def swap_pairs(self):
        current_worker = self.head
        while current_worker and current_worker.next and current_worker.next.next and current_worker.next.next.next:
            temp = current_worker.number
            current_worker.number = current_worker.next.number
            current_worker.next.number = temp

            temp = current_worker.workEX
            current_worker.workEX = current_worker.next.workEX
            current_worker.next.workEX = temp

            temp = current_worker.next.next.number
            current_worker.next.next.number = current_worker.next.next.next.number
            current_worker.next.next.next.number = temp

            temp = current_worker.next.next.workEX
            current_worker.next.next.workEX = current_worker.next.next.next.workEX
            current_worker.next.next.next.workEX = temp

            current_worker = current_worker.next.next.next.next

    def display(self):
        workers = []
        current_worker = self.head
        while current_worker:
            workers.append((current_worker.number, current_worker.workEX))
            current_worker = current_worker.next
        return workers


if __name__ == '__main__':
    linked_list_project = LinkedList()
    linked_list_project.add_worker(1, 10)
    linked_list_project.add_worker(2, 0)
    linked_list_project.add_worker(3, 3)
    linked_list_project.add_worker(4, 5)
    linked_list_project.add_worker(5, 6)
    linked_list_project.add_worker(6, 4)
    linked_list_project.add_worker(7, 2)
    linked_list_project.add_worker(8, 8)
    print("Workers' number & experience: ", linked_list_project.display())

    linked_list_project.swap_pairs()
    print("List after swapping pairs: ", linked_list_project.display())
