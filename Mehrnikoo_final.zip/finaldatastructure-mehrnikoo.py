class Node:
    def __init__(self, number, workEX):
        self.number = number
        self.workEX = workEX
        self.next = None
        self.prev = None


# class HelperNode:
#     def __init__(self, node1, node2):
#
#         self.node1 = node1.Node()
#
#         self.node2 = node2.Node()
#         #self.next = None
class Linkedlist:

    def __init__(self):
        self.head = None

    def addworker(self, number, workEX):

        new_worker = Node(number, workEX)
        if not self.head:
            self.head = new_worker
        else:
            current_worker = self.head
            while current_worker.next:
                current_worker = current_worker.next

            current_worker.next = new_worker
            new_worker.prev = current_worker

    # def move_itHalf(self):
    #     temp = None
    #     current_worker = self.head
    #     #we could use the HelperNode to put twe of the nodes in it and use it as 1 single node so we can
    #     #exchange the two, yk?
    #     while current_worker:
    #         temp = current_worker.node1
    #         current_worker.node1 = current_worker.node2
    #         current_worker.node2 = temp
    #     if temp:
    #         self.head = temp.node1
    #     pass

    def display(self):
        numB = []
        worknumB = []
        current_worker = self.head
        while current_worker:
            numB.append(current_worker.number)
            worknumB.append(current_worker.workEX)
            current_worker = current_worker.next
        return numB, worknumB

    # def merge_and_group(self):
    #     merged_pairs = []
    #     current_worker = self.head
    #     while current_worker and current_worker.next:
    #         merged_pairs.append([current_worker.next.data, current_worker.data])
    #         current_worker = current_worker.next.next
    #     return merged_pairs

if __name__ == '__main__':
    linked_list_PROJECT = Linkedlist()
    linked_list_PROJECT.addworker(1, 10)
    linked_list_PROJECT.addworker(2, 0)
    linked_list_PROJECT.addworker(3, 3)
    linked_list_PROJECT.addworker(3, 5)

    print("worker's number & experience: ", linked_list_PROJECT.display())

    # result = Linkedlist.merge_and_group()
    # print("swap the two: ", result)
